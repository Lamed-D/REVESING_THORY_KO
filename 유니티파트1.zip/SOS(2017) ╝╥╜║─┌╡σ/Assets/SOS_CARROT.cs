﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SOS_CARROT : MonoBehaviour {

	float Speed = 0; // 회전속도

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {


		// 회전
		transform.Rotate(0, 0, Speed);
		Speed -= 0.01f;
	}
}
